<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Opdracht 3A</h1>
<?php 
    $taartPrijs=15;
    $korting=2;
    $aantalTaarten=7;
    $aantalKlanten=3;

    
    echo "<p> de prijs van " . $aantalTaarten . " taarten is € " . $aantalTaarten * $taartPrijs . ",-</p>";  
    echo "<p> de prijs van 1 taart met korting is € " . $taartPrijs - $korting . ",-</p>";  
    echo "<p> de prijs van 1 taart met korting is € " . ($taartPrijs - $korting) * $aantalTaarten . ",-</p>";  
    echo "<p> je houd " . fmod($aantalTaarten, $aantalKlanten) . " taart over </p>";
    echo "<p> de prijs van 1 taart met willekurige korting is € " . $taartPrijs - rand(2 , 4). ",-</p>";  
?>


</body>

</html