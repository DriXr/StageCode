<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Opdracht 3B</h1>
<?php 
$var1 = 10; 
$var2 = 2.5; 

echo "<p> de waarde van " . '$var1'."=$var1</p> ";
echo "<p> de waarde van " . '$var2'."=$var2</p> ";
echo "<p> de uitkomst van " . '$var1 / $var2 ' . "= 10/2.5= " . $var1 / $var2 . "</p>";
echo "<p> de uitkomst van " . '$var1 * $var2 ' . "= 10*2.5= " . $var1 * $var2 . "</p>";
echo "<p> de uitkomst van " . '$var1 + $var2 ' . "= 10+2.5= " . $var1 + $var2 . "</p>";
echo "<p> de uitkomst van " . '$var1 - $var2 ' . "= 10-2.5= " . $var1 - $var2 . "</p>";
?>


</body>

</html