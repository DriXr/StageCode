<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<h1>Opdracht 4A</h1>
<body>
    <?php
    if(is_int(sqrt(81)))
    {
        echo "De wortel uit 81 is een int.";
    }
    else
    {
        echo "De wortel uit 81 is geen int.";
    }
    echo "<br>";
    if(is_float(sqrt(81)))
    {
        echo "De wortel uit 81 is een float.";
    }
    else
    {
        echo "De wortel uit 81 is geen float.";
    }
    echo "<br>";
    if(is_numeric(sqrt(81)))
    {
        echo "De wortel uit 81 is een numeric";
    }
    else
    {
        echo "De wortel uit 81 is geen numeric";
    }
    echo "<br>";
    echo "<br>";


    if(is_int(2^3/4))
    {
        echo "De uitkomst van 2^3/4 is een int.";
    }
    else
    {
        echo "De uitkomst van 2^3/4 is geen int.";
    }
    echo "<br>";
    if(is_float(2^3/4))
    {
        echo "De uitkomst van 2^3/4 is een float.";
    }
    else
    {
        echo "De uitkomst van 2^3/4 is geen float.";
    }
    echo "<br>";
    if(is_numeric(2^3/4))
    {
        echo "De uitkomst van 2^3/4 is een numeric.";
    }
    else
    {
        echo "De uitkomst van 2^3/4 is geen numeric.";
    }
    echo "<br>";
    echo "<br>";

    if(is_int("2"))
    {
        echo '"2" is een int.';
    }
    else
    {
        echo '"2" is geen int.';
    }
    echo "<br>";
    if(is_float("2"))
    {
        echo '"2" is een float.';
    }
    else
    {
        echo '"2" is geen float.';
    }
    echo "<br>";
    if(is_numeric("2"))
    {
        echo '"2" is een numeric.';
    }
    else
    {
        echo '"2" is geen numeric.';
    }
    echo "<br>";
    echo "<br>";

    if(is_int("2 auto's"))
    {
        echo "2 auto's is een int.";
    }
    else
    {
        echo "2 auto's is geen int.";
    }
    echo "<br>";
    if(is_float("2 auto's"))
    {
        echo "2 auto's is een float.";
    }
    else
    {
        echo "2 auto's is geen float.";
    }
    echo "<br>";
    if(is_numeric("2 auto's"))
    {
        echo "2 auto's is een numeric.";
    }
    else
    {
        echo "2 auto's is geen numeric.";
    }
    echo "<br>";
    echo "<br>";
    echo "<h1>Afronden</h1>";

    $Afronding1 = 17/sqrt(81);

    echo "17/sqrt(81) is afgerond: " . round($Afronding1, 2);
    echo "<br>";
    echo "5.51 naar beneden afgerond is: " . floor(5.51);
    echo "<br>";
    echo "5.51 naar boven afgerond is: " . ceil(5.51);
    echo "<br>";

    echo "<h1>Bonus Opdracht</h1>";

    $pi=3.141592654;

    echo "Pi afgerond naar beneden afgerond op 3 cijfers naar de komma is: " . floor($pi * 1000) / 1000;
    ?>
</body>
</html>