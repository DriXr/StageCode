<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Opdracht 2</h1>
    <?php
    $first = "The quick brown";
    $colorold = "brown";
    $colornew = "yellow";
    $space = " ";
    $animal = "fox";
    $second = "jumps over the lazy dog.";
    $times = 4;

    echo ucwords($first);
    echo "<br>";
    echo str_replace($colorold, ucfirst($colornew), $first);
    echo "<br>";
    echo str_replace("dog", $animal, $second);
    echo "<br>";
    echo str_repeat($animal . $space , 4);
    ?>
</body>
</html>